package com.sistemaempresa.inv_reagentes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvReagentesApplicationTests {

	@Test
	void contextLoads() {
	}

}
